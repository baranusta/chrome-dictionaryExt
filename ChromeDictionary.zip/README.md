# chrome-dictionaryExt
Turkish-Eng Dictionary extension
