


var rule = {
  conditions:["dblclick"];
};

chrome.runtime.onInstalled.addListener(function(callback){

})
